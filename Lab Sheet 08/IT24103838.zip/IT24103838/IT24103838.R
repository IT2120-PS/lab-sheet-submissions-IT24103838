setwd("C:\\Users\\IT24103838\\Desktop\\IT24103838")

set.seed(123)


# Task 1

population_weights <- rnorm(200, mean = 2.5, sd = 0.3)

pop_mean <- mean(population_weights)
pop_sd <- sd(population_weights)

cat("Population Mean:", round(pop_mean, 4), "\n")
cat("Population Standard Deviation:", round(pop_sd, 4), "\n")


# Task 2

sample_means <- c()
sample_sds <- c()

for (i in 1:25) {
  sample_i <- sample(population_weights, size = 6, replace = TRUE)
  sample_means <- c(sample_means, mean(sample_i))
  sample_sds <- c(sample_sds, sd(sample_i))
}

cat("\nSample Means:\n")
print(round(sample_means, 4))

cat("\nSample Standard Deviations:\n")
print(round(sample_sds, 4))


# Task 3

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("\nMean of Sample Means:", round(mean_of_sample_means, 4), "\n")
cat("Standard Deviation of Sample Means:", round(sd_of_sample_means, 4), "\n")

expected_sd_sample_means <- pop_sd / sqrt(6)
cat("Expected SD of Sample Means (Population SD / sqrt(n)):", round(expected_sd_sample_means, 4), "\n")

